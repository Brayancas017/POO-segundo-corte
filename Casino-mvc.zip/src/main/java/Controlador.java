public class Controlador {
    public VistaJuego vista;
    public Jugador jugador;
    public Juego juego;

    public Controlador(VistaJuego vista) {
        this.vista = vista;
        vista.setControlador(this);
    }

    public void registrarJugador(String nombre, double saldoInicial) {
        jugador = new Jugador(nombre, saldoInicial);
        vista.mostrarMensaje("Jugador registrado: " + nombre + ", Saldo inicial: " + saldoInicial);
    }

    public void jugarRonda(double cantidadApuesta) {
        juego = new Juego(jugador, cantidadApuesta);
        String resultado = juego.jugar();
        String estado = resultado.contains("¡Ganaste!") ? "Ganaste" : "Perdiste";

        // Actualizar la vista con el resultado del lanzamiento y el estado del juego
        vista.mostrarResultadoLanzamiento(juego.getUltimoLanzamiento());
        vista.mostrarEstadoJuego(estado);
        vista.mostrarMensaje(resultado);

        // Actualizar el saldo del jugador
        double saldoActualizado = jugador.getSaldo();
        vista.mostrarMensaje("Saldo actual: " + saldoActualizado);

        // Verificar si el jugador ha ganado 10 veces
        if (jugador.haGanado10Veces()) {
            vista.mostrarMensaje(jugador.getNombre() + " ha ganado 10 veces y debe dejar el juego.");
            // Aquí puedes agregar cualquier lógica adicional para finalizar el juego
        } else {
            // Esperar a que el usuario decida jugar de nuevo
            vista.jugarDeNuevoButton.setEnabled(true);
        }
    }
}