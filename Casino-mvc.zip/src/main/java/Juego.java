import java.util.Random;

public class Juego {
    public Jugador jugador;
    public double cantidadApuesta;
    public Random random;
    public int ultimoLanzamiento;

    public Juego(Jugador jugador, double cantidadApuesta) {
        this.jugador = jugador;
        this.cantidadApuesta = cantidadApuesta;
        this.random = new Random();
    }

    public int lanzarDados() {
        ultimoLanzamiento = random.nextInt(6) + 1 + random.nextInt(6) + 1;
        return ultimoLanzamiento;
    }

    public int getUltimoLanzamiento() {
        return ultimoLanzamiento;
    }

    public String jugar() {
        int primerLanzamiento = lanzarDados();
        if (primerLanzamiento == 2 || primerLanzamiento == 3 || primerLanzamiento == 12) {
            jugador.setSaldo(jugador.getSaldo() - cantidadApuesta);
            return "Obtuviste " + primerLanzamiento + ". ¡Perdiste!";
        } else if (primerLanzamiento == 7 || primerLanzamiento == 11) {
            jugador.setSaldo(jugador.getSaldo() + cantidadApuesta);
            jugador.incrementarVictorias();
            return "Obtuviste " + primerLanzamiento + ". ¡Ganaste!";
        } else {
            int punto = primerLanzamiento;
            while (true) {
                int lanzamiento = lanzarDados();
                if (lanzamiento == 7) {
                    jugador.setSaldo(jugador.getSaldo() - cantidadApuesta);
                    return "Obtuviste 7. ¡Perdiste!";
                } else if (lanzamiento == punto) {
                    jugador.setSaldo(jugador.getSaldo() + cantidadApuesta);
                    jugador.incrementarVictorias();
                    return "Obtuviste " + lanzamiento + ". ¡Ganaste!";
                }
            }
        }
    }
}