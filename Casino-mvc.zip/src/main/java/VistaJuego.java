import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VistaJuego {
    public JFrame frame;
    public JTextField nombreJugadorField;
    public JTextField saldoInicialField;
    public JTextField cantidadApuestaField;
    public JTextArea mensajeArea;
    public JLabel resultadoLanzamientoLabel;
    public JLabel estadoJuegoLabel;
    public JButton registrarJugadorButton;
    public JButton jugarDeNuevoButton;
    public Controlador controlador;

    public VistaJuego() {
        frame = new JFrame("Juego de Dados");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        frame.setLayout(new GridLayout(9, 2));

        // Nombre del jugador
        frame.add(new JLabel("Nombre del jugador:"));
        nombreJugadorField = new JTextField();
        frame.add(nombreJugadorField);

        // Saldo inicial
        frame.add(new JLabel("Saldo inicial:"));
        saldoInicialField = new JTextField();
        frame.add(saldoInicialField);

        // Cantidad a apostar
        frame.add(new JLabel("Cantidad a apostar:"));
        cantidadApuestaField = new JTextField();
        cantidadApuestaField.setEditable(false);
        frame.add(cantidadApuestaField);

        // Resultado del lanzamiento
        frame.add(new JLabel("Resultado del lanzamiento:"));
        resultadoLanzamientoLabel = new JLabel();
        frame.add(resultadoLanzamientoLabel);

        // Estado del juego
        frame.add(new JLabel("Estado del juego:"));
        estadoJuegoLabel = new JLabel();
        frame.add(estadoJuegoLabel);

        // Área de mensaje
        mensajeArea = new JTextArea();
        mensajeArea.setEditable(false);
        frame.add(new JScrollPane(mensajeArea));

        // Botón para registrar jugador
        registrarJugadorButton = new JButton("Registrar Jugador");
        registrarJugadorButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registrarJugador();
            }
        });
        frame.add(registrarJugadorButton);

        // Botón para jugar de nuevo
        jugarDeNuevoButton = new JButton("Jugar de nuevo");
        jugarDeNuevoButton.setEnabled(false);
        jugarDeNuevoButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jugarNuevaRonda();
            }
        });
        frame.add(jugarDeNuevoButton);

        frame.setVisible(true);
    }

    private void registrarJugador() {
        String nombre = nombreJugadorField.getText();
        double saldoInicial = Double.parseDouble(saldoInicialField.getText());

        if (nombre.isEmpty() || saldoInicial <= 0) {
            mensajeArea.append("Debe ingresar un nombre de jugador y un saldo inicial válido.\n");
            return;
        }

        // Deshabilitar campos y botón de registro después de registrar al jugador
        nombreJugadorField.setEditable(false);
        saldoInicialField.setEditable(false);
        registrarJugadorButton.setEnabled(false);

        // Habilitar campo de cantidad a apostar y botón de jugar de nuevo
        cantidadApuestaField.setEditable(true);
        jugarDeNuevoButton.setEnabled(true);

        controlador.registrarJugador(nombre, saldoInicial);
    }

    private void jugarNuevaRonda() {
        double cantidadApuesta = Double.parseDouble(cantidadApuestaField.getText());
        controlador.jugarRonda(cantidadApuesta);
    }

    public void mostrarMensaje(String mensaje) {
        mensajeArea.append(mensaje + "\n");
    }

    public void mostrarResultadoLanzamiento(int resultado) {
        resultadoLanzamientoLabel.setText(String.valueOf(resultado));
    }

    public void mostrarEstadoJuego(String estado) {
        estadoJuegoLabel.setText(estado);
    }

    public void setControlador(Controlador controlador) {
        this.controlador = controlador;
    }
}