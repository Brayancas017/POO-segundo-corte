import javax.swing.SwingUtilities;

public class Main {
  public static void main(String[] args) {
    // Ejecuta la interfaz gráfica en el hilo de despacho de eventos de Swing
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        // Crea una instancia de VistaJuego
        VistaJuego vista = new VistaJuego();

        // Crea una instancia de Controlador y le pasa la vista
        Controlador controlador = new Controlador(vista);
      }
    });
  }
}