public class Jugador {
    public String nombre;
    public double saldo;
    public int victorias;

    public Jugador(String nombre, double saldoInicial) {
        this.nombre = nombre;
        this.saldo = saldoInicial;
        this.victorias = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public int getVictorias() {
        return victorias;
    }

    public void incrementarVictorias() {
        this.victorias++;
    }

    public boolean haGanado10Veces() {
        return victorias >= 10;
    }
}
