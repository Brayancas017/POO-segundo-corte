import java.time.LocalDateTime;
import java.time.ZoneId;

public class Reloj {
    private Hora horas;
    private Minuto minutos;
    private Segundo segundos;

    public Reloj(int hora, int minuto, int segundo) {
        this.horas = new Hora(hora);
        this.minutos = new Minuto(minuto);
        this.segundos = new Segundo(segundo);
    }

    public Hora getHoras() {
        return horas;
    }

    public Minuto getMinutos() {
        return minutos;
    }

    public Segundo getSegundos() {
        return segundos;
    }

    public void incrementarSegundos() {
        segundos.incrementar();
        if (segundos.getValor() == 0) {
            minutos.incrementar();
            if (minutos.getValor() == 0) {
                horas.incrementar();
            }
        }
    }

    public static Reloj getCurrentTimeInBogota(){
        LocalDateTime horaActual = LocalDateTime.now(ZoneId.of("America/Bogota"));
        return new Reloj(horaActual.getHour(), horaActual.getMinute(), horaActual.getSecond());
    }
    
    @Override
    public String toString() {
        return horas + ":" + minutos + ":" + segundos;
    }
    
}
