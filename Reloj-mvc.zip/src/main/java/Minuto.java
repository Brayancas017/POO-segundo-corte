public class Minuto extends UnidadDeTiempo {
    public Minuto(int valor) {
        super(valor, 60);
    }
}
