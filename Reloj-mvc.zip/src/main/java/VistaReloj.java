import javax.swing.*;
import java.awt.*;

public class VistaReloj extends JFrame {
    private JLabel etiquetaHora;

    public VistaReloj() {
        etiquetaHora = new JLabel("00:00:00", SwingConstants.CENTER);
        etiquetaHora.setFont(new Font("Serif", Font.BOLD, 48));
        this.add(etiquetaHora);
        this.setTitle("Reloj");
        this.setSize(300, 150);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public void actualizarHora(String hora) {
        etiquetaHora.setText(hora);
    }
}
