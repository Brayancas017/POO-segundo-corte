public class UnidadDeTiempo {
    protected int valor;
    protected int limite;

    public UnidadDeTiempo(int valor, int limite) {
        this.limite = limite;
        setValor(valor);
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        if (valor >= 0 && valor < limite) {
            this.valor = valor;
        } 
    }

    public void incrementar() {
        valor = (valor + 1) % limite;
    }

    @Override
    public String toString() { 
        return String.format("%02d", valor);
    }
}
