public class Hora extends UnidadDeTiempo {
    public Hora(int valor) {
        super(valor, 24);
    }
}
