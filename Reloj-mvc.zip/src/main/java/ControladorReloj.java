import java.util.Timer;
import java.util.TimerTask;

public class ControladorReloj {
    private Reloj modelo;
    private VistaReloj vista;
    private Timer timer;

    public ControladorReloj(Reloj modelo, VistaReloj vista) {
        this.modelo = modelo;
        this.vista = vista;
        iniciarReloj();
    }

    private void iniciarReloj() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                modelo.incrementarSegundos();
                vista.actualizarHora(modelo.toString());
            }
        }, 0, 1000);
    }
}
