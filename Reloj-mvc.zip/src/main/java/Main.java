
public class Main {
  public static void main(String[] args) {
    Reloj modelo = Reloj.getCurrentTimeInBogota();
    VistaReloj vista = new VistaReloj();
    new ControladorReloj(modelo, vista);
  }

  
}