public class Segundo extends UnidadDeTiempo {
    public Segundo(int valor) {
        super(valor, 60);
    }
}
